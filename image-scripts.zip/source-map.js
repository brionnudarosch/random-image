const sourceMap = {
  "aHR0cDovL2V4YW1wbGUuY29tL2ltYWdlMS5qcGc=": "https://www.are.na/block/123456",
  "aHR0cDovL2V4YW1wbGUuY29tL2ltYWdlMi5qcGc=": "https://www.are.na/block/654321"
};